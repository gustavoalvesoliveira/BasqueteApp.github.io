package com.example.basquete;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int scoreTeamA;
    int scoreTeamB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void AlterarPontoA(int scoreTeamA) {
        TextView tv_contadorA;
        tv_contadorA = findViewById(R.id.contadorA);
        tv_contadorA.setText(String.valueOf(scoreTeamA));
    }

    public void AlterarPontoB(int scoreTeamB) {
        TextView tv_contadorA;
        tv_contadorA = findViewById(R.id.contadorB);
        tv_contadorA.setText(String.valueOf(scoreTeamB));
    }

    public void FreeThrowB(View view) {
        scoreTeamB = scoreTeamB + 1;
        AlterarPontoB(scoreTeamB);
    }

    public void DoisPontosB(View view) {
        scoreTeamB = scoreTeamB + 2;
        AlterarPontoB(scoreTeamB);

    }

    public void TresPontosB(View view) {
        scoreTeamB = scoreTeamB + 3;
        AlterarPontoB(scoreTeamB);
    }

    public void FreeThrowA(View view) {
        scoreTeamA = scoreTeamA + 1;
        AlterarPontoA(scoreTeamA);
    }

    public void DoisPontosA(View view) {
        scoreTeamA = scoreTeamA + 2;
        AlterarPontoA(scoreTeamA);
    }

    public void TresPontosA(View view) {
        scoreTeamA = scoreTeamA + 3;
        AlterarPontoA(scoreTeamA);
    }

    public void Reset(View view) {
        scoreTeamA = 0;
        scoreTeamB = 0;
        AlterarPontoA(scoreTeamA);
        AlterarPontoB(scoreTeamB);
    }
}
